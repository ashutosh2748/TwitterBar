/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author user
 */
public final class ExamplesVersion {
    private static final String VERSION = "4.0.4";
    private static final String TITLE = "Twitter4J examples";

    private ExamplesVersion() {
        throw new AssertionError();
    }

    public static String getVersion() {
        return VERSION;
    }

    /**
     * prints the version string
     *
     * @param args will be just ignored.
     */
    public static void main(String[] args) {
        System.out.println(TITLE + " " + VERSION);
        //System.out.print("ashutosh");
    }
}
